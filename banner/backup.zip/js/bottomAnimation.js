"use strict";
var Premium = Premium || {};

Premium.creative = {
    init: function () {


    }
}